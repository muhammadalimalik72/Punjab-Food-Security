create database food;
use food;
create table punjabfood(
id int(10),
city varchar(50),
population int(15),
primary key(id));
create table meat(
id int(10),
mid int(9),
name varchar(50),
availability int(15),
requirement int(15),
quality double(4,2),
price double(11,3),
primary key(mid),
foreign key(id) references punjabfood(id));
create table vegetables(
id int(10),
name varchar(50),
availability int(15),
requirement int(15),
quality double(4,2),
price double(11,3),
foreign key(id) references punjabfood(id));
create table cereal(
id int(10),
name varchar(50),
availability int(15),
requirement int(15),
quality double(4,2),
price double(11,3),
foreign key(id) references punjabfood(id));
create table pulses(
id int(10),
name varchar(50),
availability int(15),
requirement int(15),
quality double(4,2),
price double(11,3),
foreign key(id) references punjabfood(id));
create table dairyproduct(
id int(10),
name varchar(50),
availability int(15),
requirement int(15),
quality double(4,2),
price double(11,3),
foreign key(id) references punjabfood(id));
select * from punjabfood;
alter table dairyproduct add did int(9);
alter table dairyproduct add primary key(did);
desc meat;
show tables;

select city,population,name,availability,requirement,quality,price from punjabfood p join meat m on p.id=m.id;

select city,population,name,availability,requirement,quality,price from punjabfood p join vegetables v on p.id=v.id;