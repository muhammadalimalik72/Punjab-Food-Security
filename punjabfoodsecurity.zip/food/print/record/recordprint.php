<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "food";

$conn = new mysqli($servername, $username,'',$dbname);


if ($conn->connect_error) {
	
    die("Connection failed: " . $conn->connect_error);
}
else
{ 
//echo "Connected Database successfully";
}

?>
<!doctype html>
<html>
<head>

</head>
<body>

<h1 align="center">*************Punjab Food Security RECORD **********</h1>
<h1 align="center">Meat</h1>

<table border="1" align="center" style="line-height:25px;">
<tr>
<th>City Name</th>
<th>Population</th>
<th>Item Name</th>
<th>Availability</th>
<th>Requirement</th>
<th>Quality</th>
<th>Price</th>

</tr>
<?php
$sql = "select city,population,name,availability,requirement,quality,price from punjabfood p join meat m on p.id=m.id;";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>

<td> <?php  echo $row['city'];?></td>
<td> <?php  echo $row['population'];?></td>
<td> <?php  echo $row['name'];?></td>
<td> <?php  echo $row['availability'];?></td>
<td> <?php  echo $row['requirement'];?></td>
<td> <?php  echo $row['quality'];?></td>
<td> <?php  echo $row['price'];?></td>


 </tr>
 
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>
</body>
<body>


<h1 align="center">Vegetables</h1>

<table border="1" align="center" style="line-height:25px;">
<tr>
<th>City Name</th>
<th>Population</th>
<th>Item Name</th>
<th>Availability</th>
<th>Requirement</th>
<th>Quality</th>
<th>Price</th>

</tr>
<?php
$sql = "select city,population,name,availability,requirement,quality,price from punjabfood p join vegetables v on p.id=v.id;";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>

<td> <?php  echo $row['city'];?></td>
<td> <?php  echo $row['population'];?></td>
<td> <?php  echo $row['name'];?></td>
<td> <?php  echo $row['availability'];?></td>
<td> <?php  echo $row['requirement'];?></td>
<td> <?php  echo $row['quality'];?></td>
<td> <?php  echo $row['price'];?></td>


 </tr>
 
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>
</body>
<body>


<h1 align="center">Cereal</h1>

<table border="1" align="center" style="line-height:25px;">
<tr>
<th>City Name</th>
<th>Population</th>
<th>Item Name</th>
<th>Availability</th>
<th>Requirement</th>
<th>Quality</th>
<th>Price</th>

</tr>
<?php
$sql = "select city,population,name,availability,requirement,quality,price from punjabfood p join cereal c on p.id=c.id;";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>

<td> <?php  echo $row['city'];?></td>
<td> <?php  echo $row['population'];?></td>
<td> <?php  echo $row['name'];?></td>
<td> <?php  echo $row['availability'];?></td>
<td> <?php  echo $row['requirement'];?></td>
<td> <?php  echo $row['quality'];?></td>
<td> <?php  echo $row['price'];?></td>


 </tr>
 
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>
</body>
<body>


<h1 align="center">Pulses</h1>

<table border="1" align="center" style="line-height:25px;">
<tr>
<th>City Name</th>
<th>Population</th>
<th>Item Name</th>
<th>Availability</th>
<th>Requirement</th>
<th>Quality</th>
<th>Price</th>

</tr>
<?php
$sql = "select city,population,name,availability,requirement,quality,price from punjabfood p join pulses u on p.id=u.id;";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>

<td> <?php  echo $row['city'];?></td>
<td> <?php  echo $row['population'];?></td>
<td> <?php  echo $row['name'];?></td>
<td> <?php  echo $row['availability'];?></td>
<td> <?php  echo $row['requirement'];?></td>
<td> <?php  echo $row['quality'];?></td>
<td> <?php  echo $row['price'];?></td>


 </tr>
 
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>
</body>
<body>


<h1 align="center">Dairy Products</h1>

<table border="1" align="center" style="line-height:25px;">
<tr>
<th>City Name</th>
<th>Population</th>
<th>Item Name</th>
<th>Availability</th>
<th>Requirement</th>
<th>Quality</th>
<th>Price</th>

</tr>
<?php
$sql = "select city,population,name,availability,requirement,quality,price from punjabfood p join dairyproduct d on p.id=d.id;";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>

<td> <?php  echo $row['city'];?></td>
<td> <?php  echo $row['population'];?></td>
<td> <?php  echo $row['name'];?></td>
<td> <?php  echo $row['availability'];?></td>
<td> <?php  echo $row['requirement'];?></td>
<td> <?php  echo $row['quality'];?></td>
<td> <?php  echo $row['price'];?></td>


 </tr>
 
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>
</body>
</html>